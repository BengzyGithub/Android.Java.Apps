package niu.edu.alphonse.portfolio15b;

import android.os.AsyncTask;

public class NumberAsyncTask extends AsyncTask<Integer, Void, String>
{
    private  MainActivity mainActivity;

    public NumberAsyncTask(MainActivity mainActivity)
    {
        this.mainActivity = mainActivity;
    }//end constructor

    @Override
    protected String doInBackground(Integer... integers)
    {
        return "Your favorite number is " + integers[0] + "\nChanged by asynctask";
    }//end of doInBackground

    @Override
    protected void onPostExecute(String s)
    {
        super.onPostExecute(s);
        mainActivity.updateDisplay(s);
    }//end of  onPostExecute
}//end of NumberAsync
