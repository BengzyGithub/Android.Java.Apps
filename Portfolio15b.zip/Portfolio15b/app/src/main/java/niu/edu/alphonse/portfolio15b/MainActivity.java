/**
 * Programmers name: Alphonse Lemnsernyuy
 * Course:           CSCI 322
 * Z_ID :            z1869260
 * Portfolio Number: #15b
 * Date created:     4/25/2022
 *
 * Purpose:  To design  a simple application that will demonstrate asynchronous tasks by getting a
 * user’s favorite number and using the task to display the number on the application screen.
 */
package niu.edu.alphonse.portfolio15b;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private NumberAsyncTask task;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }//end of onCreate

    //Method to handle the button click - get the number and start the task
    public void getNumber(View view)
    {
        EditText numberET = findViewById(R.id.numberEditText);
        int favNumber  = Integer.parseInt(numberET.getText().toString());

        //create the Async task object
        task = new NumberAsyncTask(this);

        task.execute(favNumber);
    }//end of getNumber

    public  void updateDisplay(String message)
    {
        TextView messageTv = findViewById(R.id.messageTextView);

        messageTv.setText(message);
    }//end of updateDisplay

}//end of MainActivity