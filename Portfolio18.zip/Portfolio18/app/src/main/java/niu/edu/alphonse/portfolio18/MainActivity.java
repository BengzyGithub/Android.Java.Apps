/**
 * Programmers name: Alphonse Lemnsernyuy
 * Course:           CSCI 322
 * Z_ID :            z1869260
 * Portfolio Number: #18
 * Date created:     5/06/2022
 *
 * Purpose:  To design a Weather application that will use JSON data from OpenWeatherMap.org and
 * display it in a RecyclerView.
 */
package niu.edu.alphonse.portfolio18;


import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    private ArrayList<Weather> weatherList;
    private WeatherAdapter weatherAdapter;
    private RecyclerView weatherRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create the arraylist that will hold the weather data
        weatherList = new ArrayList<>();
//create the adapter that will be used to populate the recyclerview
        weatherAdapter = new WeatherAdapter(this, weatherList);
//connect to the recyclerview on the screen
        weatherRV = findViewById(R.id.weatherRecyclerView);
//use a linear layout for the recyclerview
        weatherRV.setLayoutManager(new LinearLayoutManager(this));
//set the adapter that will be used to populate the recyclerview
        weatherRV.setAdapter(weatherAdapter);

    }//end of onCreate

    //method to create the URL object from the city name
    private URL createURL(String city)
    {
        //Create strings with the password and start of the web address
        String apiKey = getString(R.string.api_key),
                baseUrl = getString(R.string.web_url);
        try
        {
            //build a url with web address, city name, imperial units (F temps), and password
            //
            String urlString = baseUrl + URLEncoder.encode(city, "UTF-8") +
                    "&units=imperial&cnt=16&APPID=" + apiKey;
            //create the URL object and return it
            return new URL(urlString);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }//end of CreateURL

    //custom asyncTask
    private class getWeatherTask extends AsyncTask<URL, Void, JSONObject>
    {
        static final String LOG_TAG = "MAIN";
        @Override
        protected JSONObject doInBackground(URL... urls)
        {
            HttpURLConnection connection = null;
            try
            {
                Log.d(LOG_TAG, "URL is " + urls[0]);
                //try to open a connection at the specified URL
                connection = (HttpURLConnection)urls[0].openConnection();
                int response = connection.getResponseCode();
                //if the connection was established
                if (response == HttpURLConnection.HTTP_OK)
                {
                    //build a string with the json data
                    StringBuilder builder = new StringBuilder();
                    try
                    {
                        //create an input stream to read the data
                        BufferedReader reader =
                                new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        //read the first string from the input
                        String line;
                        line = reader.readLine();
                        //while there is input
                        while (line != null)
                        {
                            //append the data to the json string
                            builder.append(line);
                            //read the next piece of data
                            line = reader.readLine();
                        }
                    }
                    catch (IOException ioe)
                    {
                        Log.d(LOG_TAG, getString(R.string.read_error));
                        ioe.printStackTrace();
                    }
                    //use the string of json data to create a JSON object and return it
                    return new JSONObject(builder.toString());
                }
                else
                {
                    Log.d(LOG_TAG, getString(R.string.connect_error));
                }
            }
            catch (Exception e)
            {
                Log.d(LOG_TAG, getString(R.string.connect_error));
                e.printStackTrace();
            }
            finally
            {
                connection.disconnect();
            }
            return null;
    }//end of doInbackground

        /*Method that parses the JSON data and creates Weather objects that
         * are put into the array list*/

        private void convertJSONtoArrayList(JSONObject forecast)
        {
            //clear the existing data from the arraylist
            weatherList.clear();
            try
            {
                //get the JSON array that holds the data
                JSONArray list = forecast.getJSONArray("list");
                //divide the JSON array into the individual weather objects
                for(int sub = 0; sub < list.length(); sub++)
                {
                    //retrieve the day of the week from the current array object
                    JSONObject day = list.getJSONObject(sub);
                    //retrieve the temperature for the day of the week
                    JSONObject temperatures = day.getJSONObject("temp");
                    //retrieve the weather description and image for the day of the week
                    JSONObject weather = day.getJSONArray("weather").getJSONObject(0);
                    //create a Weather object for the day of the week
                    Weather newWeather = new Weather(day.getLong("dt"),
                            temperatures.getDouble("min"),
                            temperatures.getDouble("max"),
                            day.getDouble("humidity"),
                            weather.getString("description"),
                            weather.getString("icon"));
                    //add the weather object to array list
                    weatherList.add(newWeather);
                }//end for loop
            }
            catch (JSONException jsonException)
            {
                jsonException.printStackTrace();
            }
        }//end of convert

        @Override
        protected void onPostExecute(JSONObject jsonObject)
        {
            super.onPostExecute(jsonObject);
            //populate the array list with the parsed json data
            convertJSONtoArrayList(jsonObject);
            //update the contents of the adapter/recyclerview
            weatherAdapter.notifyDataSetChanged();
            weatherRV.smoothScrollToPosition(0);
        }//end onPostExecute
    }//end of GetweatherTASK

    public void getWeather(View view)
    {
        //Retrieve the city name from the EditText and use it to create a url
        EditText cityET = findViewById(R.id.cityEditText);
        URL url = createURL(cityET.getText().toString());
        //if the url was created
        if (url != null)
        {
            dismissKeyboard(cityET);
            //create the asynctask to retrieve the weather info
            getWeatherTask weatherTask = new getWeatherTask();
            //retrieve the weather for the specified city
            weatherTask.execute(url);
        }
        else
        {
            //display an invalid url error
            Toast.makeText(MainActivity.this, R.string.invalid_url, Toast.LENGTH_LONG).show();
        }

    }
    private void dismissKeyboard(View view )
    {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }


}//end of MainActivity