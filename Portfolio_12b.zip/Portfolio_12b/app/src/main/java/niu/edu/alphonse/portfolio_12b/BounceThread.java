package niu.edu.alphonse.portfolio_12b;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class BounceThread  extends Thread
{
    private SurfaceHolder surfaceHolder;
    private AnimationArena animationArena;
    private boolean isRunning;

    //constructor
    public BounceThread (SurfaceHolder holder)
    {
        surfaceHolder = holder;
        animationArena = new AnimationArena();
        isRunning = true;
    }//end of BouceThread Constructor

    public void run()
    {
        try
        {
            while (isRunning)
            {
               //create the canvas object
                Canvas canvas = surfaceHolder.lockCanvas();

                //update the Ball location
                animationArena.update(canvas.getWidth(),canvas.getHeight());

                //draw the ball at the new location
                animationArena.draw(canvas);

                //the drawing is done so the canvas must be locked for the
                //drawing to display

                surfaceHolder.unlockCanvasAndPost(canvas);
            }//end of while loop
        }//end of try
        catch (NullPointerException npe)
        {
            npe.printStackTrace();
        }//end of catch
    }//end of run Method

    public void endBounce()
    {
        isRunning = false;
    }//end of endBounce
}//end of BounceThread class
