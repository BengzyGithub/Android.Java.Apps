package niu.edu.alphonse.portfolio_12b;

import android.graphics.Canvas;

/**
 * A custom AnimationArena class that will hold the ball and control when it moves and is drawn to the
 * canvas.
 */
public class AnimationArena
{
    private  Ball myBall;

    public AnimationArena()
    {
        myBall = new Ball();
    }//end of constructor

    //Method to update the screen
    //width - coordinate of the right side of thescrren
    //height - coordinate of the bottom of the screen

    public void update(int width, int height)
    {
        myBall.move(0,0,width,height);
    }//end of update

    //Method to draw the ball in the animation arena
    public void draw(Canvas canvas)
    {
        //set the background button on the canvas - clear the screen
        canvas.drawRGB(256,256,256);

        //draw the ball
        myBall.draw(canvas);
    }//end of draw method
}//end of Animation class
