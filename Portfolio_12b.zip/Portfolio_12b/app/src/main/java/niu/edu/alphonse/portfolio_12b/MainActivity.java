/**
 * Programmers Name: Alphonse Lemnsernyuy
 * Date:             4/11/22
 * Z_ID:             Z1869260
 * Portfolio Number: #12b
 *
 * Purpose: To design a simple application that will simulate a ball bouncing around
 * the screen at a constant velocity.
 */
package niu.edu.alphonse.portfolio_12b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FrameLayout frameLayout = findViewById(R.id.frameLout);

        BounceSurfaceView bounceSurfaceView = new BounceSurfaceView(this,null);

        frameLayout.addView(bounceSurfaceView);
    }//end of OnCreate
}//end of main