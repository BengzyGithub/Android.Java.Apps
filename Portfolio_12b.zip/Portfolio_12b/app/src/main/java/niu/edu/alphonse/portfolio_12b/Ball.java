package niu.edu.alphonse.portfolio_12b;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/**
 * A custom class to represent the ball
 */
public class Ball
{
    private final int RADIUS = 50,//size of the ball
            REVERSE = -1;

    private int x, y, velX, velY;

    public Ball()
    {
        //starting point for the center of the ball
        x = 100;
        y = 100;

        //initial "speed"  and direction of travel
        velX = 50;
        velY = 50;
    }//end of Ball constructor

    public void move( int leftWall, int topWall, int rightWall, int bottomWall )
    {
        //move the ball
        x += velX;
        y += velY;

        //if the ball has collided with the bottom or the top of the screen, change the direction that
        //the ball is traveling
        if( y > bottomWall - RADIUS )
        {
            y = bottomWall - RADIUS;
            velY *= REVERSE;
        }
        else if( y < topWall + RADIUS )
        {
            y = topWall + RADIUS;
            velY *= REVERSE;
        }


        //if the ball has collided with the right or left side of the screen, change the direction that
        //the ball is traveling
        if( x > rightWall - RADIUS )
        {
            x = rightWall - RADIUS;
            velX *= REVERSE;
        }
        else if( x < leftWall + RADIUS )
        {
            x = leftWall + RADIUS;
            velX *= REVERSE;
        }
    }//end of move

    @SuppressLint("Range")
    public void draw(Canvas canvas )
    {
        //the color of the ball
        Paint paint = new Paint();
        //paint.setColor(Color.rgb(211,216,156));
        paint.setColor(Color.rgb(255,200,100));

        //draw the ball
        canvas.drawCircle(x, y, RADIUS,paint);
    }//end of draw
}//end of Ball class
