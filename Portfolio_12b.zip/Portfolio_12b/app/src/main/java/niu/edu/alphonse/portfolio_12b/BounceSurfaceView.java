package niu.edu.alphonse.portfolio_12b;

import android.content.Context;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

public class BounceSurfaceView  extends SurfaceView
                                implements SurfaceHolder.Callback
{
    private  BounceThread bounceThread;

    //constructor

    public BounceSurfaceView(Context context, AttributeSet attrs)
    {
        super(context, attrs);

        //get the control of the drawing surface
        SurfaceHolder holder = getHolder();


        //use the 3 call back methods with the surface hoder
        holder.addCallback(this);

        //create the custom thread object with the surface holder
        bounceThread = new BounceThread(holder);
    }//end of constructor

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2)
    {

    }//end of surfaceChanged

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder)
    {
        bounceThread.start();

    }//end of surfaceCreated

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder)
    {
        bounceThread.endBounce();

        //nullify the thread using the dummy thread
        Thread thread = bounceThread;
        bounceThread = null;
        thread.interrupt();
    }//end of surfaceDestroyed
}//end of Bounce class
