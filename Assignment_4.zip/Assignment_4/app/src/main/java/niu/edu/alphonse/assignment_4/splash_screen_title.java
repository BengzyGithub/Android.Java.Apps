package niu.edu.alphonse.assignment_4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.HandlerCompat;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Handler;

public class splash_screen_title extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen_title);

        //create the timerTask object
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                //Finish splash Activity
                finish();

                //go to the main activity
                Intent mainIntent  = new Intent(splash_screen_title.this, MainActivity.class);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                startActivity(mainIntent);
            }
        };//end timer
        //create a timer object to execute the task
        Timer timer = new Timer();

        timer.schedule(timerTask,4000);
    }
}