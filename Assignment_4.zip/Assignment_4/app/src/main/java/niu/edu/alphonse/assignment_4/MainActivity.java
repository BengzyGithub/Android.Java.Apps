/**
 *  Programmers Name: Alphonse Lemnsernyuy
 *  Date:             4/11/22
 *  course:           CSCI 322
 *
 *  Purpose: To write a version of the classic fart app.
 * The application should have (at least) 4 images that function as buttons. When the user clicks on one of
 * the images, a sound that is related to the image should be played.
 */
package niu.edu.alphonse.assignment_4;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity
{
    //variables to hold the given attributes
    private ImageButton battleTBtn, legend_of_exorcistBtn,martialUnBtn,
                                            xing_chenBtn,shanHe_JianBtn,soul_LandBtn;
    private MediaPlayer battleTmp3, legend_of_exorcistmp3,martialUnmp3,
                                            xing_chenMp3,shanHe_JianMp3,soul_LandMp3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connects the Image buttons with items on the screen
        battleTBtn = findViewById(R.id.BattlethroughImBtn);
        legend_of_exorcistBtn = findViewById(R.id.LegenOfExorcissmImBtn);
        martialUnBtn = findViewById(R.id.martialUniverseImBtn);
        xing_chenBtn = findViewById(R.id.Xing_ChengBianImBtn);
        shanHe_JianBtn = findViewById(R.id.ShanHeJianImBtn);
        soul_LandBtn = findViewById(R.id.soulLandImBtn);

        //set up the drums media  player and pm3 file
        battleTmp3 = new MediaPlayer();
        battleTmp3 = MediaPlayer.create(this,R.raw.battle_through_the_heaves);

        legend_of_exorcistmp3 = new MediaPlayer();
        legend_of_exorcistmp3 = MediaPlayer.create(this,R.raw.legend_of_exorcism);

        martialUnmp3 = new MediaPlayer();
        martialUnmp3 = MediaPlayer.create(this,R.raw.martial_universe_xing);

        xing_chenMp3 = new MediaPlayer();
        xing_chenMp3 = MediaPlayer.create(this,R.raw.naruto_shipuden_xtian_bao);

        shanHe_JianMp3 = new MediaPlayer();
        shanHe_JianMp3 = MediaPlayer.create(this,R.raw.shan_he_jian_xin);

        soul_LandMp3 = new MediaPlayer();
        soul_LandMp3 = MediaPlayer.create(this,R.raw.soul_land_new_opening);


    }//end of OnCreate Method

    //method to handle the clicking on the buttons(Battle through the heavens)
    public void playBattleT(View view)
    {
        //if the battleT media player is playing
        if(battleTmp3.isPlaying())
        {
            //pause the mediaPlayer
            battleTmp3.pause();

        } else
        {
            if(legend_of_exorcistmp3.isPlaying())
            {
                legend_of_exorcistmp3.pause();
            }else if (martialUnmp3.isPlaying())
            {
                martialUnmp3.pause();
            }else if (xing_chenMp3.isPlaying())
            {
                xing_chenMp3.pause();
            }else if (shanHe_JianMp3.isPlaying())
            {
                shanHe_JianMp3.pause();
            }else if (soul_LandMp3.isPlaying())
            {
                //pause the soul land media player
                soul_LandMp3.pause();
            }

            //START the battleTmp3
            battleTmp3.start();
        }
    }//end of playBattleT

    //method to handle the clicking on the Image buttons (legend...)
    public void legendOfEx(View view)
    {
        //if the legendOfEx media player is playing
        if(legend_of_exorcistmp3.isPlaying())
        {
            //let user be able to pause the mediaPlayer
            legend_of_exorcistmp3.pause();

        }
        else
        {//if any other media starts playing, then pause the previous play

            if(battleTmp3.isPlaying())
            {
                battleTmp3.pause();
            }else if (martialUnmp3.isPlaying())
            {
                martialUnmp3.pause();
            }else if (xing_chenMp3.isPlaying())
            {
                xing_chenMp3.pause();
            }else if (shanHe_JianMp3.isPlaying())
            {
                shanHe_JianMp3.pause();
            }else if (soul_LandMp3.isPlaying())
            {
                //pause the soul land media player
                soul_LandMp3.pause();
            }

            //START the legends mp3
            legend_of_exorcistmp3.start();
        }
    }//end of playLegend

    //method to handle the clicking on the Image buttons (martial...)
    public void martialUSong(View view)
    {
        //if the legendOfEx media player is playing
        if(martialUnmp3.isPlaying())
        {
            //let user be able to pause the mediaPlayer
            martialUnmp3.pause();

        }
        else
        {//if any other media starts playing, then pause the previous play

            if(battleTmp3.isPlaying())
            {
                battleTmp3.pause();
            }else if (legend_of_exorcistmp3.isPlaying())
            {
                legend_of_exorcistmp3.pause();
            }else if (xing_chenMp3.isPlaying())
            {
                xing_chenMp3.pause();
            }else if (shanHe_JianMp3.isPlaying())
            {
                shanHe_JianMp3.pause();
            }else if (soul_LandMp3.isPlaying())
            {
                //pause the soul land media player
                soul_LandMp3.pause();
            }

            //START the martial Universe mp3
            martialUnmp3.start();
        }
    }//end of martialU

    //method to handle the clicking on the Image buttons (xingChen...)
    public void PlayXingChensong(View view)
    {
        //if the xing_Chen media player is playing
        if(xing_chenMp3.isPlaying())
        {
            //let user be able to pause the mediaPlayer
            xing_chenMp3.pause();

        }
        else
        {//if any other media starts playing, then pause the previous play

            if(battleTmp3.isPlaying())
            {
                battleTmp3.pause();
            }else if (legend_of_exorcistmp3.isPlaying())
            {
                legend_of_exorcistmp3.pause();
            }else if (martialUnmp3.isPlaying())
            {
                martialUnmp3.pause();
            }else if (shanHe_JianMp3.isPlaying())
            {
                shanHe_JianMp3.pause();
            }else if (soul_LandMp3.isPlaying())
            {
                //pause the soul land media player
                soul_LandMp3.pause();
            }

            //START the xingChen  mp3
            xing_chenMp3.start();
        }
    }//end of xingChen

    //method to handle the clicking on the Image buttons (shan_He_Jian...)
    public void PlayShanHeJianMp3(View view)
    {
        //if the shan_He_Jian media player is playing
        if(shanHe_JianMp3.isPlaying())
        {
            //let user be able to pause the mediaPlayer
            shanHe_JianMp3.pause();

        }
        else
        {//if any other media starts playing, then pause the previous play

            if(battleTmp3.isPlaying())
            {
                battleTmp3.pause();
            }else if (legend_of_exorcistmp3.isPlaying())
            {
                legend_of_exorcistmp3.pause();
            }else if (martialUnmp3.isPlaying())
            {
                martialUnmp3.pause();
            }else if (xing_chenMp3.isPlaying())
            {
                xing_chenMp3.pause();
            }else if (soul_LandMp3.isPlaying())
            {
                //pause the soul land media player
                soul_LandMp3.pause();
            }

            //START the shan_He_Jian  mp3
            shanHe_JianMp3.start();
        }
    }//end of shan_He_Jian

    //method to handle the clicking on the Image buttons (soul_Land...)
    public void PlaySoulLandmp3(View view)
    {
        //if the soul_LandMp3 media player is playing
        if(soul_LandMp3.isPlaying())
        {
            //let user be able to pause the mediaPlayer
            soul_LandMp3.pause();

        }
        else
        {//if any other media starts playing, then pause the previous play

            if(battleTmp3.isPlaying())
            {
                battleTmp3.pause();
            }else if (legend_of_exorcistmp3.isPlaying())
            {
                legend_of_exorcistmp3.pause();
            }else if (martialUnmp3.isPlaying())
            {
                martialUnmp3.pause();
            }else if (xing_chenMp3.isPlaying())
            {
                xing_chenMp3.pause();
            }else if (shanHe_JianMp3.isPlaying())
            {
                //pause the soul land media player
                shanHe_JianMp3.pause();
            }

            //START the soul_LandMp3  mp3
            soul_LandMp3.start();
        }
    }//end of soul_LandMp3

}//end of main