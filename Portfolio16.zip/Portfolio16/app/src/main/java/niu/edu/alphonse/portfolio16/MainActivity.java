/**
 * Programmers name: Alphonse Lemnsernyuy
 * Course:           CSCI 322
 * Z_ID :            z1869260
 * Portfolio Number: #16
 * Date created:     4/27/2022
 *
 * Purpose:  To design a simple application that will demonstrate the use of RecyclerView to display
 * information.The application will display the same data using different formats.
 */
package niu.edu.alphonse.portfolio16;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity
{
    private RecyclerView textRV, CheckBoxRV;
    private TextAdapter textAdapter;
    private CheckAdapter checkAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create and arraylist with the attraction data

        ArrayList<String> locations = new ArrayList<>(Arrays.asList(AttractionData.attractionArray));

        //set up the connection with the recycler view
        textRV = findViewById(R.id.textRecyclerView);

        //set up the layout for the recycler view
        textRV.setLayoutManager(new LinearLayoutManager(this));

        //populate the adapter with info in the arraylist
        textAdapter = new TextAdapter(this, locations);
        //populate the recylcer view
        textRV.setAdapter(textAdapter);

        //arraylist with attractions
        ArrayList<Attraction> attractionArrayList = new ArrayList<>();
        for (String attrName: AttractionData.attractionArray)
        {
            //create the attraction object witht the name
            Attraction attraction = new Attraction(attrName);

            //add to the arraylist
            attractionArrayList.add(attraction);
        }

        CheckBoxRV = findViewById(R.id.checkboxRecyclerView);
        CheckBoxRV.setLayoutManager(new LinearLayoutManager(this));

        checkAdapter = new CheckAdapter(this, attractionArrayList);
        CheckBoxRV.setAdapter(checkAdapter);
    }//end of onCreate

    //custom adapter to put text into the RecyclerView
    //uses a custom ViewHolder to hold the info
    private class TextAdapter extends RecyclerView.Adapter<TextAdapter.ViewHolder>
    {
        //add in constructor
        //       onCreateViewHolder - called when a view is created
        //       onBindViewHolder - called when the contents of a view are replaced
        //       getItemCount - size of the dataset

        //   custom ViewHolder

        private ArrayList<String> data;
        private LayoutInflater inflater;

        public TextAdapter(Context context, ArrayList<String> newData)
        {
            data = newData;
            inflater = LayoutInflater.from(context);
        }//end constructor

        @NonNull
        @Override
        public TextAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
        {
            //Create a view and associate it with the custom layout file
            View view = inflater.inflate(R.layout.custom_textview, parent, false);

            //Use the view to create and return a ViewHolder
            return new ViewHolder(view);
        }//end onCreate

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position)
        {
            //get the data from the array list
            String textData = data.get(position);

            //replace the info that is in the textview of the viewholder
            holder.recyclerTV.setText(textData);
        }//end onBind

        @Override
        public int getItemCount()
        {
            return data.size();
        }//end getItemCount

        //custom ViewHolder
        public class ViewHolder extends RecyclerView.ViewHolder
        {
            public TextView recyclerTV;

            public ViewHolder(@NonNull View itemView)
            {
                super(itemView);

                //connect the local textview to the one on the custom layout file
                recyclerTV = itemView.findViewById(R.id.recyclerTextView);
            }//end constructor
        }//end ViewHolder
    }//end TextAdapter

    //custom adapter for the displaying checkbox in the recyclerview
    private class CheckAdapter extends RecyclerView.Adapter<CheckAdapter.ViewHolder>
    {
        private ArrayList<Attraction> attractions;
        private LayoutInflater inflater;

        public CheckAdapter(Context context, ArrayList<Attraction> newAttractions)
        {
            attractions = newAttractions;
            inflater = LayoutInflater.from(context);

        }//end of constructor

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
        {
            View view = inflater.inflate(R.layout.custom_checkbox, parent, false);
            return new ViewHolder(view);
        }//end of onCreate

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position)
        {
            //create the attration object that holds the info
            final  Attraction attraction = attractions.get(position);

            //set the text field on the checkBox
            holder.recyclerCB.setText(attraction.getAttractionName());

            //respond to the uncheck/check of the checkbox
            holder.recyclerCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked)
                {
                    //set up the status for the attraction
                    attraction.setChecked(isChecked);

                    //update the database item;
                }
            });

            //set the status of Checkbox
            //saving the information to make sure that if application is closed and re-opended
            //it will still be checked
            holder.recyclerCB.setChecked(attraction.isChecked());
        }//end of onBindViewHolder

        @Override
        public int getItemCount()
        {
            return attractions.size();
        }//end of getItemCount

        public class ViewHolder extends RecyclerView.ViewHolder
        {
            public CheckBox recyclerCB;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                recyclerCB = itemView.findViewById(R.id.recyclerCheckBox);
            }//end of constructor
        }//end of viewHolder class
    }//end of CheckAdapter

}//end of MainActivity