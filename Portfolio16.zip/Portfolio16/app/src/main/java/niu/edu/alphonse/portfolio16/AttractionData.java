package niu.edu.alphonse.portfolio16;
//Create a class to hold the names of attractions in Chicago. It requires a single data member: an array of
//Strings with the various names.
class AttractionData
{
    public static final String [] attractionArray = {"Art Institute of Chicago", "Magnificent Mile",
            "Willis Tower", "Navy Pier", "Water Tower",
            "Wrigley Field", "Guaranteed Rate Field", "United Center",
            "Allstate Arena"};
}//end AttractionData class
