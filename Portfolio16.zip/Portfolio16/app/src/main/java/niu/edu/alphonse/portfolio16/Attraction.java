package niu.edu.alphonse.portfolio16;

/**
 * Create a class that represents a single attraction. The class has two data members: a string to hold the
 * attraction’s name and an integer that holds whether the attraction has been selected (this is used with the
 * custom checkbox layout)
 */
public class Attraction
{
    private String attractionName;
    private int isChecked;

    //constructor that creates an object using the passed in name
    //and sets the isChecked data member to 0 to represent
    //false (not checked)

    public Attraction(String name)
    {
        attractionName = name;
        isChecked = 0;
    }


    //Getter and Setter for the String data member

    public String getAttractionName()
    {
        return attractionName;
    }

    public void setAttractionName(String newName)
    {
        attractionName = newName;
    }


    //Getter and Setter for the int data member
    //the value is treated as a boolean

    public boolean isChecked()
    {
        return isChecked == 1? true: false;
    }

    public void setChecked(boolean checked)
    {
        if(checked)
            isChecked = 1;
        else
            isChecked = 0;
    }
}//end Attraction class