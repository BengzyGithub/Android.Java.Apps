/**
 * Programmers name: Alphonse Lemnsernyuy
 * Course:           CSCI 322
 * Z_ID :            z1869260
 * Portfolio Number: #12a
 * Date created:     4/06/2022
 *
 * Purpose:  To design a simple application that will use a thread to update and ->
 * display a counter every second.
 */

package niu.edu.alphonse.portfolio_12;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //data members to link with items on screen
    private TextView CountTV;
    private  Integer counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect the data members with items on the screen
        CountTV = findViewById(R.id.CountTextView);
        counter = 0;

        //create a thread object
        Thread thread = new Thread(countNumber);
        thread.start();
    }//end of onCreate

    @Override
    protected void onStart() {
        super.onStart();
        //set the initial counter to zero
        counter = 0;
    }//end of onStart

    private Handler threadHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message)
        {
            CountTV.setText(counter.toString());
            return true;
        }
    });//end of THandler

    //Method to execute one time and increment a counter by one.
    private Runnable countNumber = new Runnable() {
        @Override
        public void run()
        {
            while (true)
            {
                //send an empty message to a Handler,
                threadHandler.sendEmptyMessage(0);
                counter++; //increment counter by 1

                try
                {
                    //delay for 1 second
                    Thread.sleep(1000);
                }
                catch (InterruptedException ie)
                {
                    ie.printStackTrace();
                }
            }//end of while
        }//end of run Method
    };


}//end of mainActivity