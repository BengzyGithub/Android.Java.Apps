package niu.edu.alphonse.portfolio17;
/**
 * Create a custom adapter to load data into the RecyclerView. The class should extend the RecyclerView
 * Adapter class, which should work with a custom ViewHolder. It should contain two arguments: an ArrayList
 * of State objects and a LayoutInflator. It should contain a simple constructor that takes a Context and
 * ArrayList as its arguments. It should also contain the necessary callback methods.
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StateAdapter extends RecyclerView.Adapter<StateAdapter.ViewHolder>
{
    private ArrayList<State> states;
    private LayoutInflater inflater;

    public StateAdapter(Context context, ArrayList<State> newStates)
    {
        states = newStates;
        inflater = LayoutInflater.from(context);

    }//end of constructor

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        //set up the connection with the custom cml file
        View view = inflater.inflate(R.layout.state_view, parent, false);
        return  new ViewHolder(view);
    }//end of onCreateView

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
         //Get the state object at the currrent position
        State state = states.get(position);

        //use the state object to populate the 2 textviews
        holder.stateAbbrTV.setText("State" + state.getStateAbbr());
        holder.stateZipTV.setText("Zip" + state.getStateZip());
    }//end of onBind

    @Override
    public int getItemCount()
    {
        return states.size();
    }//end of getItemCount

    //custom viewHolder
    public class ViewHolder extends RecyclerView.ViewHolder
    {
        public TextView stateAbbrTV, stateZipTV;

        //Constructor

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            stateAbbrTV = itemView.findViewById(R.id.stateAbbrTextView);
            stateZipTV = itemView.findViewById(R.id.stateZipTextView);
        }//end of Constructor
    }//end of ViewHolder class
}//end of StateAdapter
