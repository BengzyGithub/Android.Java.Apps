package niu.edu.alphonse.portfolio17;

/**
 * Create a simple class to represent a single State. It should contain data members to hold the State
 * abbreviation (String) and a zip code (int). Implement a basic constructor for the class and get methods for
 * the two data members.
 */
public class State
{
    private String stateAbbr;
    private int stateZip;

    public State( String newAbbr, int newZip )
    {
        stateAbbr = newAbbr;
        stateZip = newZip;
    }//end constructor

    public String getStateAbbr()
    {
        return stateAbbr;
    }//end getStateAbbr

    public int getStateZip()
    {
        return stateZip;
    }//end getStateZip
}//end State