/**
 * Programmers name: Alphonse Lemnsernyuy
 * Course:           CSCI 322
 * Z_ID :            z1869260
 * Portfolio Number: #17
 * Date created:     5/02/2022
 *
 * Purpose:  To design a simple application that will access JSON data from a webpage
 * and display it in a RecyclerView.
 */
package niu.edu.alphonse.portfolio17;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    private ArrayList<State> stateList;
    private StateAdapter stateAdapter;
    private RecyclerView StateRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create the arraylist
        stateList = new ArrayList<>();


        //create the state adapter
        stateAdapter = new StateAdapter(this,stateList);

        //create the recycler view
        StateRV = findViewById(R.id.stateRecyclerView);
        StateRV.setLayoutManager(new LinearLayoutManager(this));

        StateRV.setAdapter(stateAdapter);
    }//end of onCreate

    //Method to handle the button click
    public void getData(View view)
    {
        //create the string with the url
         String urlString = getString(R.string.web_url);

         try
         {
             //create the url object
             URL url = new URL(urlString);

             //create the asyncTask
             StateTask task = new StateTask();
             task.execute(url);
         }
         catch (Exception exception)
         {
             exception.printStackTrace();
         }
    }//end of getData

    //Method to convvert the json info and put it in the arraylist
    private void convertJSONtoArraylist(JSONObject stateInfo)
    {
        //remove all the info from the array list to make sure info is current
        stateList.clear();

        try
        {
            //retrieve the json array from the json object
            JSONArray list = stateInfo.getJSONArray("places");

            for(int sub = 0; sub < list.length(); sub++)
            {
                //retrieve the json object
                JSONObject jsonObject = list.getJSONObject(sub);

                //create the state object
                State newState = new State(jsonObject.getString("State"), jsonObject.getInt("Zip"));

                //add the state to arraylist
                stateList.add(newState);
            }//end of for loop
        }//end of try block
        catch (JSONException jsonException)
        {
            jsonException.printStackTrace();
        }//end of catch
    }//end of convert Method

    //async task to retrieve the state json data
    private class StateTask extends AsyncTask<URL, String, JSONObject>
    {
        @Override
        protected JSONObject doInBackground(URL... urls)
        {
            HttpURLConnection connection = null;
            try
            {
                //attempt to set up the connection
                connection = (HttpURLConnection) urls[0].openConnection();
                int responseCode = connection.getResponseCode();
                if(responseCode == HttpURLConnection.HTTP_OK)
                {
                    StringBuilder builder = new StringBuilder();
                    try {
                        //create an input stream to read the data
                        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

                        String line  = reader.readLine();

                        while (line != null)
                        {
                            //append the line to the stringbuilder
                            builder.append(line);

                            //get the next piece of information
                            line = reader.readLine();
                        }
                    }//end of inner try
                    catch (IOException ioException)
                    {
                        publishProgress("read error");

                        ioException.printStackTrace();
                    }//end of inner catch

                    return new JSONObject(builder.toString());
                }else
                {
                    publishProgress("bad/poor connection");
                }//end of else
            }//end of try
            catch(Exception exception)
            {
                publishProgress("error opening the connection - bad url");
                exception.printStackTrace();
            }
            finally
            {
                //disconnect the url connection
                connection.disconnect();
            }
            return null;
        }//end of doINbackground

        @Override
        protected void onProgressUpdate(String... values)
        {
            super.onProgressUpdate(values);

            Toast.makeText(MainActivity.this,values[0],Toast.LENGTH_LONG).show();

        }//end of onPROGRESS

        @Override
        protected void onPostExecute(JSONObject jsonObject)
        {
            super.onPostExecute(jsonObject);
            //get the info from json onject and put in the arraylist
            convertJSONtoArraylist(jsonObject);

            //update the adapter with new information
            stateAdapter.notifyDataSetChanged();
        }//end of onPostExecute
    }//end of StateTask

}//end of mainActivity