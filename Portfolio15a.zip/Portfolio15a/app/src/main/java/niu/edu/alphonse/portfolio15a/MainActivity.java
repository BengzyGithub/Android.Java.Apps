/**
 * Programmers name: Alphonse Lemnsernyuy
 * Course:           CSCI 322
 * Z_ID :            z1869260
 * Portfolio Number: #15a
 * Date created:     4/25/2022
 *
 * Purpose:  To design a simple application that will demonstrate asynchronous tasks by simulating
 * the downloading of information.
 */
package niu.edu.alphonse.portfolio15a;
import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private ProgressBar downloadPB;
    private TextView PercentTV, resultsTV;
    private Button downloadBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect the variables with the items on the screen
        downloadPB = findViewById(R.id.downloadProgressBar);
        PercentTV = findViewById(R.id.percentTextView);
        resultsTV = findViewById(R.id.resultTextView);
        downloadBtn = findViewById(R.id.downloadButton);
    }//end of onCreate

    //Download Button
    public void startDownload(View view)
    {
        //disable the download Button
        downloadBtn.setEnabled(false);

        //start the download
        DownloadAsyncTask task = new DownloadAsyncTask();
        task.execute();
    }//end of startDownload

    public void clearDisplay(View view)
    {
        resultsTV.setText("");

        //reset the textfield
        PercentTV.setText(R.string.download_text);

        downloadPB.setProgress(0);
    }//end of clear download

    private class DownloadAsyncTask extends AsyncTask<Void, Integer, Void>
    {
        int progressPercentage;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //set the progress to 0 since the download is starting
            progressPercentage = 0;

            //display the percentage
            PercentTV.setText(R.string.download_text);

            //let the user know what methods are being executed
            resultsTV.setText(resultsTV.getText() + "\n In onProExecute() Method");
            resultsTV.setText(resultsTV.getText() + "\n Completed onProExecute() Method");
            resultsTV.setText(resultsTV.getText() + "\n Going into doInBackground() Method");
            resultsTV.setText(resultsTV.getText() + "\n Background work is starting");
        }//end of OnpreExecute

        @Override
        protected Void doInBackground(Void... voids)
        {
            while (progressPercentage < 100)
            {
                progressPercentage += 2;

                //update the download percentage
                publishProgress(progressPercentage);

                //delay
                SystemClock.sleep(300);
            }
            return null;
        }//end doInBackground

        @Override
        protected void onProgressUpdate(Integer... values)
        {
            super.onProgressUpdate(values);

            //update the progress bar
            downloadPB.setProgress(values[0]);

            //update the percentage
            PercentTV.setText("download: " + values[0] + "%");
        }//end of onProgressUpdate

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            //finish up the download
            resultsTV.setText(resultsTV.getText() + "\nBackground work is completed");
            resultsTV.setText(resultsTV.getText() + "\nIn onPostExecute() Method");

            PercentTV.setText("download complete");

            //enable the download button
            downloadBtn.setEnabled(true);
        }// end of onPostExecute
    }//end of downloadAsyncTask
}//end of main