/**
 * Create a custom View class that will function as the drawing canvas, which means that it should extend the
 * View class. It should contain at least 2 data members: a Paint object for drawing the circles and a
 * 2dimensional array of integers to hold the positions of where the circles will be drawn. The constructor
 * should take a Context argument. It should instantiate the array of integers and set up the color and how the
 * circle will be drawn. The class should also contain an onDraw method since it extends the View class. This
 * method should draw all the circles on the canvas. The class should also have a method that will update the
 * array data member and then re-draw the canvas. The method should take 1 argument: a 2-dimensional
 * array of integers that will be used for updating the positions.
 */

package niu.edu.alphonse.portfolio13;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.Arrays;

public class LetterView  extends View
{
    //constants
    private static final int NUM_CIRCLES = 19;
    private static final int NUM_COORDS = 2;

    private Paint paint;
    private int [][] letterPositions;

    //constructor

    public LetterView(Context context)
    {
        super(context);
        //create the array of integers
        letterPositions = new int[NUM_CIRCLES][NUM_COORDS];

        //integer to hold the paint color for drawing circles
        //a = transparency, 0 = fully Transparent, 255 = Oppaque

        int circleColor = Color.argb(255,148,205,222);

        //create the paint object
        paint = new Paint();

        //line style for drawing the circles
        paint.setStyle(Paint.Style.STROKE);

        //set up the width for the paint stroke
        paint.setStrokeWidth(10.0f);

        //set up the color for the paint
        paint.setColor(circleColor);
    }//end of Constructor

    /**
     * OnDraw Method to draw the circle
     * needed because we are extending teh View class
     */
    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);

        //loop to draw the 19 circles
        for(int cnt = 0; cnt < NUM_CIRCLES; cnt++)
        {
            canvas.drawCircle(letterPositions[cnt][0] + 50, letterPositions[cnt][1]+ 200, 80,paint);
        }
    }//end of OnDraw Method

    /**
     * Method to update the array coordinates and call the OnDraw Method
     */

    public void update(int [][] values)
    {
        //replace the old values in the letterPositions array with the new ones
        letterPositions = Arrays.copyOf(values,values.length);

        //reDraw the canvas by calling the onDraw(but not directly)
        invalidate();
    }  //end of update


}//end of LetterVIEW cLASS
