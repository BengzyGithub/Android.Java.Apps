package niu.edu.alphonse.portfolio13;

/**
 * Create a custom class to represent the letters that will be drawn. The class should have 3 data members: a
 * 2-dimensional array of integers that will hold the coordinates for the first letter, a 2-dimensional array of
 * integers that will hold the coordinates for the second letter, and a 2-dimensional array of integers that will
 * hold the coordinates for the third letter. All the data members should be publicly available since this class is
 * just used to hold information. The class is available on Blackboard. Each array will hold 19 sets of
 * coordinates.
 */
public class LetterDesign
{
    public static final int [][] artA = {
            {300,0}, {200,100}, {300,100}, {400,100},
            {100,200}, {500,200}, {100,300}, {500,300},
            {100,400}, {200,400}, {300,400}, {400,400},
            {500,400}, {0,500}, {100,500}, {500,500},
            {600,500}, {0,600}, {600,600} };

    public static final int [][] artB = {
            {100,0}, {200,0}, {300,0}, {400,0},
            {100,100}, {500,100}, {100,200}, {500,200},
            {100,300}, {300,300}, {400,300}, {100,400},
            {500,400}, {100,500}, {500,500}, {100,600},
            {200,600}, {300,600}, {400,600} };

    public static final int [][] artC = {
            {300,0}, {400,0}, {500,0}, {200,100},
            {300,100}, {600,100}, {100,200}, {200,200},
            {600,200}, {100,300}, {200,300}, {100,400},
            {200,400}, {200,500}, {300,500}, {600,500},
            {300,600}, {400,600}, {500,600} };
}//end LetterDesign