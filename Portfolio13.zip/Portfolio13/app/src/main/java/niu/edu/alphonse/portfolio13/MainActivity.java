/**
 * Programmer's name: Alphonse Lemnsernyuy
 * Zid:               z1869260
 * Date:              4/13/22
 * Project name:      Portfolio 13
 *
 * Purpose:          To design an application that will use multiple threads to animate
 * the drawing of different letters on the screen.
 */
package niu.edu.alphonse.portfolio13;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.FrameLayout;

import java.util.PrimitiveIterator;

public class MainActivity extends AppCompatActivity
{
    //constants
    private static final int NUM_OBJECT =19, X_POS = 0, Y_POS = 1, NUM_COLUMNS = 2;

    private Thread calculateMovementThread, drawMovementThread;

    private LetterView letterView;
    private FrameLayout letterLO;

    private  int [][] currentPositions;
    private int [][] finalPositions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize the starting methods
        initialize();

        //connects the frameLayout to the screen

        letterLO = findViewById(R.id.letterLayout);

        //create the letterView
        letterView = new LetterView(this);

        //add the LetterView to the layout
        letterLO.addView(letterView);
        //create the threads

        calculateMovementThread = new Thread(calculateMovement);
        drawMovementThread = new Thread(drawMovement);

        //start the threads
        calculateMovementThread.start();
        drawMovementThread.start();

    }//end of OnCreate

    /**
     * Method to initialize the starting (and ending optionally) poits fior the circles
     */

    private void initialize()
    {
        //create the arrays
        currentPositions = new int[NUM_OBJECT][NUM_COLUMNS];
        finalPositions = new int[NUM_OBJECT][NUM_COLUMNS];

        //initailize the starting positions
        for(int sub = 0; sub < NUM_OBJECT;sub++)
        {
            currentPositions[sub][X_POS] = 10;
            currentPositions[sub][Y_POS] = 10;

            //can set up the finalPositions array as well
        }//end of for loop
    }//end of initialize routine

    //Method to handle the buttons
    public void createA(View view)
    {
        for(int sub = 0; sub < NUM_OBJECT; sub++)
        {
            finalPositions[sub][X_POS] = LetterDesign.artA[sub][X_POS];
            finalPositions[sub][Y_POS] = LetterDesign.artA[sub][Y_POS];

        }
    }//end of CreateA

    public void createB(View view)
    {
        for(int sub = 0; sub < NUM_OBJECT; sub++)
        {
            finalPositions[sub][X_POS] = LetterDesign.artB[sub][X_POS];
            finalPositions[sub][Y_POS] = LetterDesign.artB[sub][Y_POS];

        }
    }//end of CreateB

    public void createC(View view)
    {
        for(int sub = 0; sub < NUM_OBJECT; sub++)
        {
            finalPositions[sub][X_POS] = LetterDesign.artC[sub][X_POS];
            finalPositions[sub][Y_POS] = LetterDesign.artC[sub][Y_POS];

        }
    }//end of CreateC

    //Create the message by updating the View
    public Handler threadHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message)
        {
            letterView.update(currentPositions);
            return false;
        }
    });//end of threadHandler

    /**
     * Runnables
     * CalculatesMovement - compute the positions of the circles on the canvas
     * every 200 milliseconds
     * current position is based on the distance to the final position divided by 5
     * @note: 5 is the circle moves 1/5th of the distance to the final position
     */

    private Runnable calculateMovement = new Runnable()
    {
        private  static final int DELAY = 200;

        @Override
        public void run()
        {
            try
            {
                while (true)
                {
                    //update the current postions
                    for(int sub = 0; sub < NUM_OBJECT; sub++)
                    {
                        currentPositions[sub][X_POS] += (finalPositions[sub][X_POS]) - currentPositions[sub][X_POS] /5;
                        currentPositions[sub][Y_POS] += (finalPositions[sub][Y_POS]) - currentPositions[sub][Y_POS] /5;
                    }//end of for loop
                    Thread.sleep(DELAY);
                }//end of while
            }//end of try
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }//end of catch

        }//end of Run
    };//end of calculate movement runnable

    /**
     * DrawMovement runnable
     * send a message every 200 milliseconds to re-draw the circle
     */

    private Runnable drawMovement = new Runnable()
    {
        private static final int DELAY = 200;
        @Override
        public void run()
        {
            try
            {
                while (true)
                {
                    Thread.sleep(DELAY);
                    threadHandler.sendEmptyMessage(0);
                }
            }
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }
        }
    };//end of drawmovement

}//end of ActivityMain