package niu.edu.alphonse.portfolio14;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Point;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class UpdateActivity extends AppCompatActivity
{
    private DatabaseManager databaseManager;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        databaseManager = new DatabaseManager(this);
        updateView();
    }//end of OnCreate

    private void updateView()
    {
        //get the information from the database
        ArrayList<Product> products = databaseManager.selectAll();

        //if there is info in the database
        if(products.size()>0)
        {
            ScrollView scrollView = new ScrollView(this);
            GridLayout gridLayout = new GridLayout(this);

            //set the contexts adn columns for the grid
            gridLayout.setRowCount(products.size() + 1);
            gridLayout.setColumnCount(4);

            //create the button handler
            ButtonHandler handler = new ButtonHandler();

            //determin the size of the screen
            Point point = new Point();
            getWindowManager().getDefaultDisplay().getSize(point);
            int width = point.x;

            //proccess the pproducts in thearraylist
            for(Product product: products)
            {
                //handle the id number
                TextView idTV = new TextView(this);
                idTV.setText("" + product.getId());
                idTV.setGravity(Gravity.CENTER);

                //handle the product
                EditText nameET = new EditText(this);
                nameET.setText(product.getName());
                nameET.setId(product.getId() * 10);

                //HANDLE the product price
                EditText priceET = new EditText(this);
                priceET.setText("" + product.getPrice());
                priceET.setId(product.getId() * 10 +1);
                priceET.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL);

                //create a button to start the update process
                Button button = new Button(this);
                button.setText(R.string.update_button_label);
                button.setId(product.getId());
                button.setOnClickListener(handler);

                //put the 4 pieces into the gridLayout
                gridLayout.addView(idTV, (int) (width * 0.1), ViewGroup.LayoutParams.WRAP_CONTENT);
                gridLayout.addView(nameET, (int) (width * 0.4), ViewGroup.LayoutParams.WRAP_CONTENT);
                gridLayout.addView(priceET, (int) (width * 0.15), ViewGroup.LayoutParams.WRAP_CONTENT);
                gridLayout.addView(button, (int) (width * 0.35), ViewGroup.LayoutParams.WRAP_CONTENT);
            }//end of for loop

            //generate the back button to go back to the  main activity
            Button backButton = new Button(this);
            backButton.setText(R.string.back_button_label);
            backButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
                    finish();
                }
            });

            //set up the parameters to place the  back button
            GridLayout.Spec rowSpec = GridLayout.spec(products.size(), 1),
                            colSpec = GridLayout.spec(0,4);

            ViewGroup.LayoutParams params = new GridLayout.LayoutParams(rowSpec, colSpec);

            //attach the parameters to the back button
            backButton.setLayoutParams(params);

            backButton.setWidth(width);
            backButton.setHeight((int) (width * 0.10));

            //backButton.setText(Gravity.CENTER);
            gridLayout.addView(backButton);

            //add the gridLayout to the scrollView
            scrollView.addView(gridLayout);

            //display the scrollview
            setContentView(scrollView);

        }//end of if
    }

    private class ButtonHandler implements View.OnClickListener
    {
        @Override
        public void onClick(View view)
        {
            int productID = view.getId();

            EditText nameET = findViewById(10 * productID),
                    priceET = findViewById(10 * productID + 1);

            String nameStr = nameET.getText().toString(),
                    priceStr = priceET.getText().toString();

            //convert the price to the a double then update the database entry
            try
            {
                double price = Double.parseDouble(priceStr);

                databaseManager.updateByID(productID, nameStr, price);

                updateView();
            }

            catch (NumberFormatException nfe)
            {
                Toast.makeText(UpdateActivity.this, "Update price error", Toast.LENGTH_SHORT).show();
            }//END OF CATCH
        }//end of Onclick
    }//end of BHandler
}//end of UpdateActivity