package niu.edu.alphonse.portfolio14;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import niu.edu.alphonse.portfolio14.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Programmers name: Alphonse Lemnsernyuy
 * Course:           CSCI 322
 * Z_ID :            z1869260
 * Portfolio Number: #14
 * Date created:     4/18-20/2022
 *
 * Purpose:  To design a simple database application that will act as a store of some type of product.
 * The store will have the ability to add, delete, and update products.
 * The application will also demonstrate the use of menus and the floating action button.
 */
public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private DatabaseManager databaseManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                /*Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();*/
                Intent helpIntent = new Intent(MainActivity.this,HelpActivity.class);
                startActivity(helpIntent);
            }
        });
    }//end of Oncreate

    @Override
    protected void onResume() {
        super.onResume();
        updateScreen();
    }//end of OnResume

    private void updateScreen()
    {
        String dataBaseContentStr;

        //create the dataBase
        databaseManager = new DatabaseManager(this);

        //put the title into the string object
        dataBaseContentStr = "Objectives/to_do_list in the database \n\n";

        //get the info from the database
        ArrayList<Product> products = databaseManager.selectAll();

        //process the array list
        for(Product product: products)
        {
            //append each of the products into the string
            dataBaseContentStr += product.productToString() + "\n";
        }//end of loop

        //connect to the textView and put the string info
        TextView dataBaseTV = findViewById(R.id.dataBaseTextView);
        dataBaseTV.setText(dataBaseContentStr);
        dataBaseTV.setTextSize(30);

    }//end of updateScreen

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //no inspection SimplifiableIfStatement
        if (id == R.id.action_add)
        {
            Toast.makeText(this,"ADD option", Toast.LENGTH_SHORT).show();

            Intent addIntent = new Intent(MainActivity.this,InsertActivity.class);
            startActivity(addIntent);
            return true;
        }else if(id == R.id.action_editing)
        {
            Toast.makeText(this,"EDIT option", Toast.LENGTH_SHORT).show();

            Intent updateIntent = new Intent(MainActivity.this,UpdateActivity.class);
            startActivity(updateIntent);
            return true;
        }else if(id == R.id.action_delete)
        {
            Toast.makeText(this,"EDIT option", Toast.LENGTH_SHORT).show();

            Intent deleteIntent = new Intent(MainActivity.this,DeleteActivity.class);
            startActivity(deleteIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}//end of MainActivity