package niu.edu.alphonse.portfolio14;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
/**
 * Programmers name: Alphonse Lemnsernyuy
 * Course:           CSCI 322
 * Z_ID :            z1869260
 * Portfolio Number: #14
 * Date created:     4/18-20/2022
 *
 * Purpose:  To Create a custom class to handle database insertion operations.
 */
public class InsertActivity extends AppCompatActivity
{
    private DatabaseManager databaseManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        //create the database
        databaseManager = new DatabaseManager(this);

    }//end of OnCreate

    //Method to add the items
    public void addItem(View view)
    {
        //get the info fromt he editTextFIELD
        EditText nameET = findViewById(R.id.itemNameEditText),
        priceET = findViewById(R.id.itemPriceEditText);

        String nameStr = nameET.getText().toString(),
        priceStr = priceET.getText().toString();

        //put the info into the database
        try {
            double price = Double.parseDouble(priceStr);

            Product newProduct  = new Product(0,nameStr,price);

            databaseManager.insertProduct(newProduct);

        }
        catch (NumberFormatException nfe)
        {
            Toast.makeText(this, "price Error", Toast.LENGTH_SHORT).show();
        }

        //clear the information fields and put the focus in the name on the field
        nameET.setText("");
        priceET.setText("");

        nameET.requestFocus();


    }//end of AddItem Method

    //Method to handle the Button to go back to main activity
    public void goBack(View view)
    {
        finish();
    }//end of goBack
}//end of Insert