package niu.edu.alphonse.portfolio14;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class splash_Screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        //create the timerTask object
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                //Finish splash Activity
                finish();

                //go to the main activity
                Intent mainIntent  = new Intent(splash_Screen.this, MainActivity.class);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                startActivity(mainIntent);
            }
        };//end timer
        //create a timer object to execute the task
        Timer timer = new Timer();

        timer.schedule(timerTask,4000);
    }
}