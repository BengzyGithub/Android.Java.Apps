package niu.edu.alphonse.portfolio14;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;

public class DeleteActivity extends AppCompatActivity {
    private DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseManager = new DatabaseManager(this);

        updateView();

    }//end of OnCreate

    private void updateView()
    {
        ArrayList<Product> products = databaseManager.selectAll();
        ScrollView scrollView = new ScrollView(this);
        RelativeLayout relativeLayout = new  RelativeLayout(this);

        RadioGroup radioGroup = new RadioGroup(this);

        //process the arraylist of products
        for(Product product: products)
        {
            //create a radioButton to add the radio group
            RadioButton radioButton = new RadioButton(this);

            radioButton.setId(product.getId());
            radioButton.setText(product.productToString());

            //add the radio button to the radio group
            radioGroup.addView(radioButton);
        }//end of for loop

        //create a custom handler and attach to the radiogroup
        RadioButtonHandler handler = new RadioButtonHandler();
        radioGroup.setOnCheckedChangeListener(handler);

        //Add the radioGroup to the  ScrollView
        scrollView.addView(radioGroup);

        //Add the Scrollview to the RelativeLayout
        relativeLayout.addView(scrollView);

        //Create a back button to get back to the main Activity
        Button backButton = new Button(this);
        backButton.setText(R.string.back_button_label);
        backButton.setBackgroundColor(getResources().getColor(R.color.blue));
        backButton.setTextColor(getResources().getColor(R.color.white));
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                finish();
            }
        });

        //format the button layout in the relative laypout
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        params.addRule(RelativeLayout.CENTER_HORIZONTAL);
        params.setMargins(0,0,0,50);


        //add the button to the relative layout using the parameters
        relativeLayout.addView(backButton,params);

        //display the relative layout
        setContentView(relativeLayout);
    }//end of updateView

    //custom Handler for touching the radio button
    private class RadioButtonHandler implements RadioGroup.OnCheckedChangeListener
    {
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int checkedID)
        {
            //delete the selected products from the database
            databaseManager.deleteByID(checkedID);

            Toast.makeText(DeleteActivity.this, "Product Deleted", Toast.LENGTH_SHORT).show();
            updateView();
        }//end of checkChanged
    }//end of RadioButtonHandler class

}//end of Delete Activity