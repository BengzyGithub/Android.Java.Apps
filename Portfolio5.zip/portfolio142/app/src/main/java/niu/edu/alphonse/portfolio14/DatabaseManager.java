package niu.edu.alphonse.portfolio14;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.stream.Stream;

/**
 * A custom class to handle database operations. It should extend the SQLiteOpenHelper class and
 * contain a constructor, onCreate, onUpgrade, insert, selectAll, delete, and update methods. 
 */
public class DatabaseManager extends SQLiteOpenHelper
{
    private  static final String DATABLE_NAME = "productDB",
                                 TABLE_NAME = "productTable",
                                 ITEM_ID = "id",
                                 ITEM_NAME = "name",
                                 ITEM_PRICE = "prie";

    private static final int DATABASE_VERSION = 1;

    //constructor


    public DatabaseManager(@Nullable Context context)//@Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version)
    {
        super(context, DATABLE_NAME, null, DATABASE_VERSION);
    }//end of constructor

    //two required Methods: onCreate and ONUPGRAD

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        String sqlCreate = "create table " + TABLE_NAME + "( " +
                ITEM_ID + " integer primary key autoincrement, "  +
                ITEM_NAME + " text, " +
                ITEM_PRICE + " real )";

        sqLiteDatabase.execSQL(sqlCreate);
    }//end of onCreate

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1)
    {
        String sqlDrop = "drop table if exists " + TABLE_NAME;

        sqLiteDatabase.execSQL(sqlDrop);

    }//end of onUpgrade

    //Method to insert data into the table in rowmajo order
    public void insertProduct (Product product)
    {
        String sqlInsert = "insert into " + TABLE_NAME +
                " values( null, '" + product.getName() + "', " +
                "'" + product.getPrice() + "' )";

        //get the database that we are adding to
        SQLiteDatabase database = getWritableDatabase();

        //insert the product into the database
        database.execSQL(sqlInsert);

        //close the database
        database.close();
    }

    //Method to
    public ArrayList<Product> selectAll()
    {
        String sqlSelect = "select * from " + TABLE_NAME;

        //GET THE DATABASE
        SQLiteDatabase database = getWritableDatabase();

        //create a cursor to proccess the database info one row at a time
        Cursor cursor = database.rawQuery(sqlSelect, null);

        //CREATE Array list to hold the info
        ArrayList<Product>  products = new ArrayList<>();

        //loop that process the cursor object
        while (cursor.moveToNext())
        {
            //get the id, the name and the price from the current cursor
            Integer currentID = cursor.getInt(0);
            String currentName = cursor.getString(1);
            Double currentPrice = cursor.getDouble(2);


            //create a product object
            Product product = new Product(currentID,currentName, currentPrice);

            //add the product to the array list
            products.add(product);

        }//end loop
        //close the database
        database.close();

        return products;

    }//end selectAll

    //Method to delete the Item by the ID number
    public void deleteByID(int id)
    {
        String sqlDelete = "delete from " + TABLE_NAME + " where " + ITEM_ID + " = " + id;

        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sqlDelete);
        database.close();
    }//end of deleteMethod

    //Method to update a database item
    public void updateByID(int id, String name, double price)
    {
        String sqlUpdate = "update " + TABLE_NAME + " set " +
                ITEM_NAME + " = '" + name + "', " +
                ITEM_PRICE + " = '" + price + "'" +
                " where " + ITEM_ID + " = " + id;

        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sqlUpdate);
        database.close();
    }

}//end of DatabaseManager
